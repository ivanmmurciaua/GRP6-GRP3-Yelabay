﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class CategoriaCAD 
    {
        public CategoriaCAD()
        {
        }

        public bool createCategoria(CategoriaEN catEn)
        {
            return true;
        }

        public bool updateCategoria(CategoriaEN catEn)
        {
            return true;
        }
        public bool deleteCategoria(CategoriaEN catEn)
        {
            return true;
        }
        
    }
}
