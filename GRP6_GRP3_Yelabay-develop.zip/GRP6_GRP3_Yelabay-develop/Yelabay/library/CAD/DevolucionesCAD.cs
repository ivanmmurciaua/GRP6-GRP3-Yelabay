﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    class DevolucionesCAD
    {
        public DevolucionesCAD()
        {

        }

        public bool createDevolucion(DevolucionesEN devEn)
        {
            return true;
        }

        public bool updateDevolucion(DevolucionesEN devEn)
        {
            return true;
        }

        public bool deleteDevolucion(DevolucionesEN devEn)
        {
            return true;
        }
    }
}
